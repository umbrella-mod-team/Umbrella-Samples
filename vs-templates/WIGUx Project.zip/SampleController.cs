﻿using UnityEngine;
using WIGU;

namespace $safeprojectname$
{
    public class $safeprojectname$Controller : MonoBehaviour
    {
        static ILogger logger = ServiceProvider.Instance.GetService<ILogger>();

        void Start()
        {
            logger.Log($"{GetType().Assembly.FullName} Start");
        }

        void Update()
        {
            logger.Log($"{GetType().Assembly.FullName} Update");
        }
    }
}
